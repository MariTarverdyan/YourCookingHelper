package com.example.myapplication7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity3 extends AppCompatActivity {
    private Button b;
    ListView lv;
    ArrayAdapter<String> adp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        b = (Button) findViewById(R.id.button12);
        b.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openMainActivity2();
            }
        });
        String[] myGeners = {"1", "2" , "3", "4", "5","6","7","8","9","10"};


        lv = (ListView) findViewById(R.id.list1);

        adp = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,myGeners);
        lv.setAdapter(adp);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String p = Integer.toString(position);
                Intent i = new Intent(MainActivity3.this, MainActivity7.class);
                i.putExtra("position",p);
                startActivity(i);


            }});


    }
    public void openMainActivity2(){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
}