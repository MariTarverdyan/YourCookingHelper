package com.example.myapplication7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

public class MainActivity7 extends AppCompatActivity {
    private Button buttonback;
    ImageView i;
    String text;
    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        i = (ImageView) findViewById(R.id.receptImage);
        t = (TextView) findViewById(R.id.recept);


        String p = getIntent().getStringExtra("position");
        Toast.makeText(getApplicationContext(),p,Toast.LENGTH_SHORT).show();
        if(p == "0"){
            String string ="";
            try {
                InputStream is = getAssets().open("mytxt.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                string = new String(buffer);

            } catch (Exception e) {
                e.printStackTrace();

            }
            t.setText(text);

            i.setImageDrawable(getDrawable(R.drawable.ic_launcher_background));
        }else if(p == "1"){
            try {
                InputStream is = getAssets().open("recept1.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                text = new String(buffer);

            } catch (Exception e) {
                e.printStackTrace();
                text+=e.toString();
            }
            t.setText(text);

            i.setImageDrawable(getDrawable(R.drawable.ic_launcher_foreground));
        }

        buttonback = (Button) findViewById(R.id.backButton);
        buttonback.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openMainActivity3();
            }

    });}
    public void openMainActivity3(){
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }
}












